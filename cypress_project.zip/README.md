# Projeto de Automação UI com Cypress

Este repositório contém testes automatizados em **Cypress** para as funcionalidades:

- Login
- Cadastro
- Produtos

## 🚀 Como executar

1. Clone este repositório:
   ```bash
   git clone <url-do-repositorio>
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Execute o Cypress:
   ```bash
   npx cypress open
   ```

## 📂 Estrutura do projeto

```
/cypress
  └── e2e
      ├── login.cy.js
      ├── cadastro.cy.js
      └── produtos.cy.js
```

## 📝 Observações

- Substitua as URLs (`https://seusite.com/...`) pelo endereço real da aplicação que deseja testar.
- Os testes cobrem cenários básicos de login, cadastro e manipulação do carrinho de compras.
