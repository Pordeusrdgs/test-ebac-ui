describe('Funcionalidade: Produtos', () => {
  it('Listar produtos', () => {
    cy.visit('https://seusite.com/produtos')
    cy.get('.produto').should('have.length.greaterThan', 0)
  })

  it('Adicionar produto ao carrinho', () => {
    cy.visit('https://seusite.com/produtos')
    cy.get('.produto').first().find('button').click()
    cy.get('#carrinho').should('contain', '1 item')
  })

  it('Remover produto do carrinho', () => {
    cy.visit('https://seusite.com/produtos')
    cy.get('.produto').first().find('button').click()
    cy.get('#carrinho').should('contain', '1 item')
    cy.get('#remover').click()
    cy.get('#carrinho').should('contain', '0 itens')
  })
})