describe('Funcionalidade: Cadastro', () => {
  it('Cadastro com sucesso', () => {
    cy.visit('https://seusite.com/cadastro')
    cy.get('#nome').type('Rodrigo Teste')
    cy.get('#email').type('teste@teste.com')
    cy.get('#senha').type('123456')
    cy.get('button[type="submit"]').click()
    cy.contains('Cadastro realizado com sucesso').should('be.visible')
  })

  it('Cadastro com dados inválidos', () => {
    cy.visit('https://seusite.com/cadastro')
    cy.get('#nome').type('Rodrigo Teste')
    cy.get('button[type="submit"]').click()
    cy.contains('Preencha todos os campos obrigatórios').should('be.visible')
  })
})