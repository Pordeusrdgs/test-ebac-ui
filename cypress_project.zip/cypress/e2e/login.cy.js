describe('Funcionalidade: Login', () => {
  it('Login com sucesso', () => {
    cy.visit('https://seusite.com/login')
    cy.get('#usuario').type('usuario_valido')
    cy.get('#senha').type('senha_valida')
    cy.get('button[type="submit"]').click()
    cy.contains('Bem-vindo').should('be.visible')
  })

  it('Login com falha', () => {
    cy.visit('https://seusite.com/login')
    cy.get('#usuario').type('usuario_invalido')
    cy.get('#senha').type('senha_errada')
    cy.get('button[type="submit"]').click()
    cy.contains('Usuário ou senha inválidos').should('be.visible')
  })
})